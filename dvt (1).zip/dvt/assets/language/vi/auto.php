<?php

    return [
        'alert' => [
            'enable_autoload_success'  => 'Đã <strong>bật</strong> chức năng không tải lại trang',
            'disable_autoload_success' => 'Đã <strong>tắt</strong> chức năng không tải lại trang'
        ]
    ];