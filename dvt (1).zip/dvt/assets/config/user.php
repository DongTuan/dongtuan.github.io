<?php

    if (defined('LOADED') == false)
        exit;

    return [
        'b4d3e8f8623950a758ff5810d3c54e2e' => [
            'username' => 'Admin',
            'email' => '',
            'password' => '$2y$10$aO2R/v32X.aHuy2SG3LAOu0aPxgmOCEdpjEpUoMF/mnBzQrpSF62a',
            'position' => 8,
            'create_at' => 1566482517,
            'modify_at' => 0,
            'login_at' => 1713279264,
            'band_at' => 0,
            'band_of' => '',
        ],

    ];

?>