<?php

    if (defined('LOADED') == false)
        exit;

    return [
        'http_host' => 'https://xn--ngtun-4ya2214cnka.vn/dvt',
        'enable_disable' => [
            'autoload' => true,
        ],

    ];

?>